
<style>
body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    background-color: #f9f9f9;
    color: #333;
    margin: 0;
    padding: 0;
}
.container {
    width: 80%;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
h1, h2, h3 {
    text-align: center;
    color: #fff;
    padding: 10px;
}
h1 {
    background-color: #0056b3;
    font-size: 32px;
}
h2 {
    background-color: #007bff;
    font-size: 28px;
}
h3 {
    background-color: #0099ff;
    font-size: 24px;
}
p {
    font-size: 1rem;
    color: #555;
    text-align: justify;
}
.image-center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    max-width: 50%;
    height: auto;
}
</style>



![](./media/media/image1.png){width="1.2986111111111112in"
height="1.5298611111111111in"}[Universidad Nacional Autónoma de
México ]{.smallcaps}

![](./media/media/image2.png){width="1.1194444444444445in"
height="1.261111111111111in"}Facultad de Ingeniería

Semestre 2024-2

Redes de Datos Seguras

Grupo. 6  

Proyecto 3

Prof.: Ing. Edgar Martínez Meza

Brigada 3

  Barrera Peña Víctor Miguel     315346219
------------------------------ -----------
  Ramírez González José Miguel   420053583
  Sánchez Manzano Mariana        411026622

Actividad
=========

El proyecto deberá contar con las especificaciones dadas el primer día
de clases en el documento impreso, aunado a lo que se especifica a
continuación:

-   Los equipos serán de dos o tres personas máximo.

-   El proyecto contempla la creación de un servidor de autenticación y
    de archivos que permitirá conectarse desde un cliente con sistema
    operativo Windows o Linux del cual distribución, pero permitirá
    conectarse a ambos, aunque no de manera simultánea.

-   El equipo servidor para la autenticación del cliente Linux deberá
    tener activos los servicios de NFS y NIS.

-   El equipo servidor para la autenticación del cliente Windows deberá
    tener activo el servicio de SAMBA.

-   El equipo cliente Linux deberá poder autenticarse desde el inicio
    del sistema operativo y automáticamente importar todos los archivos
    en la cuenta de usuario creada en el servidor.

-   El equipo cliente Windows deberá poder autenticarse desde el inicio
    del sistema operativo y automáticamente importar todos los archivos
    en la cuenta de usuario creada en el servidor.

-   El proyecto que se llevará a cabo es una simulación del laboratorio
    de computación salas "A" y "B" (Computación para Ingenieros). El
    equipo deberá entregar un informe por escrito que contenga todas las
    instalaciones que se llevaron a cabo, así como las modificaciones de
    configuración que se realizaron en cada uno de los archivos. La
    distribución de Linux que utilicen es independiente.

Introducción
============

1.  **¿Qué es Samba?**

**Samba** es un proyecto de software libre que implementa el protocolo
de archivos compartidos de Windows para sistemas operativos de tipo
UNIX. Básicamente, Samba permite que computadoras con GNU/Linux, Mac OS
X o Unix se relacionen como servidores o clientes en redes basadas en
Windows. Aquí tienes algunos conceptos clave y pasos para configurar un
servidor Samba:

-   Samba es una implementación del protocolo **SMB** (Server Message
    Block) creado por Microsoft. Su objetivo es permitir que sistemas no
    Microsoft (originalmente sistemas UNIX) intercambien archivos e
    impresoras con sistemas Windows.

-   Samba implementa los protocolos **NetBIOS** y **SMB**, lo que le
    permite establecer comunicación entre máquinas Unix y productos
    Microsoft Windows.

2.  **Funcionamiento de Samba:**

    -   Samba utiliza dos demonios (programas que se ejecutan en segundo
        plano):

        -   **smbd**: Permite la compartición de archivos e impresoras
            sobre la red SMB, además de proporcionar verificación y
            autorización para el acceso de clientes SMB.

        -   **nmbd**: Busca a través del servicio **Windows Internet
            Name Service (WINS)** y brinda ayuda mediante un
            visualizador.

    -   Estos demonios proporcionan los recursos compartidos a los
        clientes SMB en la red.

Desarrollo
==========

Paso 1: instalar Debian

![Interfaz de usuario gráfica, Texto Descripción generada
automáticamente](./media/media/image3.png){width="3.954640201224847in"
height="3.313432852143482in"}

![Captura de pantalla de un celular Descripción generada
automáticamente](./media/media/image4.png){width="4.007462817147856in"
height="3.3576891951006123in"}

Paso 2: Instalar samba

----------------------------
  sudo apt-get install samba
  ----------------------------

3.  **Configuración de Samba:**

    -   La configuración de Samba en Linux se realiza mediante la
        edición de un solo archivo ubicado en /etc/samba/smb.conf.

    -   Aquí tienes un ejemplo básico de configuración:

    -   \[global\]

    -   workgroup = PRUEBAGROUP

    -   server string = Samba %v

    -   wins support = no

    -   load printers = no

    -   security = user

    -   map to guest = bad user

    -   guest ok = yes

        -   Puedes personalizar esta configuración según tus
            necesidades.

4.  **Proyecto de Simulación:**

    -   Para tu proyecto, debes crear un servidor de autenticación y
        archivos que permita la conexión desde clientes con sistemas
        operativos Windows o Linux.

    -   El equipo servidor para la autenticación del cliente Linux debe
        tener activos los servicios de **NFS** y **NIS**.

    -   El equipo servidor para la autenticación del cliente Windows
        debe tener activo el servicio de **SAMBA**.

    -   Los equipos cliente (Linux y Windows) deben poder autenticarse
        desde el inicio del sistema operativo y automáticamente importar
        todos los archivos en la cuenta de usuario creada en el
        servidor.

    -   Al final, entrega un informe por escrito que detalle todas las
        instalaciones realizadas y las modificaciones de configuración
        en los archivos.

¡Buena suerte con tu proyecto!
[[😊^1^](https://www.profesionalreview.com/2017/03/25/servidor-samba-conceptos-y-configuracion-rapida/)^[2](http://profesores.elo.utfsm.cl/~agv/elo322/1s17/projects/reports/Samba/Samba.pdf)[3](http://somebooks.es/12-2-que-es-samba/)^]{.underline}

Configuración de red de VirtualBox para una red interna

![](./media/media/image5.png){width="6.14583552055993in"
height="4.020833333333333in"}

Configuración de red del servidor

![](./media/media/image6.png){width="6.14583552055993in"
height="2.9583333333333335in"}

Configuración de red del cliente

![](./media/media/image7.png){width="6.14583552055993in"
height="2.9583333333333335in"}

Capturas servidor NIS

Instalación y configuración del servidor NIS

![](./media/media/image8.png){width="4.68079615048119in"
height="0.3055708661417323in"}

![](./media/media/image9.png){width="4.333556430446194in"
height="0.23104330708661416in"}

![](./media/media/image10.png){width="4.277997594050744in"
height="0.2222331583552056in"}

![](./media/media/image11.png){width="4.277997594050744in"
height="0.6111428258967629in"}

![](./media/media/image12.png){width="3.9168678915135606in"
height="0.4444674103237095in"}

![](./media/media/image13.png){width="4.916919291338583in"
height="2.555686789151356in"}

![](./media/media/image14.png){width="6.14583552055993in"
height="6.072915573053368in"}

![](./media/media/image15.png){width="6.14583552055993in"
height="4.875in"}

![](./media/media/image16.png){width="6.14583552055993in"
height="3.5in"}

![](./media/media/image17.png){width="4.264107611548557in"
height="0.23612314085739283in"}

![](./media/media/image18.png){width="6.14583552055993in"
height="2.5833333333333335in"}

![](./media/media/image19.png){width="6.14583552055993in"
height="0.3854166666666667in"}

Creación de usuario NIS

![](./media/media/image20.png){width="4.708575021872266in"
height="0.26390201224846893in"}

![](./media/media/image21.png){width="5.5419510061242345in"
height="0.2916819772528434in"}

Contraseña: 1928

![](./media/media/image22.png){width="4.4168941382327205in"
height="0.8194860017497813in"}

![](./media/media/image23.png){width="4.528010717410324in"
height="0.3055708661417323in"}

![](./media/media/image24.png){width="4.528010717410324in"
height="0.3055708661417323in"}

![](./media/media/image25.png){width="4.528010717410324in"
height="0.3055708661417323in"}

![](./media/media/image26.png){width="4.736353893263342in"
height="0.3055708661417323in"}

![](./media/media/image27.png){width="4.083333333333333in"
height="5.0in"}

![](./media/media/image28.png){width="3.7640824584426946in"
height="1.0139413823272092in"}

Capturas cliente NIS

![](./media/media/image29.png){width="4.000205599300087in"
height="0.3055708661417323in"}

![](./media/media/image30.png){width="4.000205599300087in"
height="0.6528116797900263in"}

![](./media/media/image31.png){width="3.8196402012248467in"
height="0.47224628171478567in"}

![](./media/media/image32.png){width="6.14583552055993in"
height="6.04166447944007in"}

![](./media/media/image33.png){width="6.14583552055993in"
height="2.78125in"}

![](./media/media/image34.png){width="5.000255905511811in"
height="2.402900262467192in"}

![](./media/media/image35.png){width="6.14583552055993in"
height="4.197916666666667in"}

![](./media/media/image36.png){width="4.041874453193351in"
height="0.26390201224846893in"}

![](./media/media/image37.png){width="4.889140419947506in"
height="0.8472659667541558in"}

Instalación y configuración de NFS

![](./media/media/image38.png){width="6.14583552055993in"
height="0.25in"}

![](./media/media/image39.png){width="6.145833333333333in"
height="1.9270833333333333in"}

![](./media/media/image40.png){width="3.555738188976378in"
height="0.4305774278215223in"}

![](./media/media/image41.png){width="5.208600174978128in"
height="0.2777919947506562in"}

![](./media/media/image42.png){width="5.444724409448819in"
height="0.2777919947506562in"}

![](./media/media/image43.png){width="4.333556430446194in"
height="0.2777919947506562in"}

![](./media/media/image44.png){width="5.000255905511811in"
height="0.2777919947506562in"}

Capturas cliente NFS

![](./media/media/image45.png){width="4.5557895888013995in"
height="0.2777919947506562in"}

![](./media/media/image46.png){width="3.694634733158355in"
height="0.2777919947506562in"}

![](./media/media/image47.png){width="4.166881014873141in"
height="0.26390201224846893in"}

![](./media/media/image48.png){width="5.0974846894138235in"
height="0.26390201224846893in"}

![](./media/media/image49.png){width="4.528010717410324in"
height="0.8194860017497813in"}

![](./media/media/image50.png){width="6.111424978127734in"
height="0.23612314085739283in"}

![](./media/media/image51.png){width="6.14583552055993in"
height="2.59375in"}

![](./media/media/image52.png){width="5.319720034995625in"
height="2.15288823272091in"}

Login por consola desde el cliente

![](./media/media/image53.png){width="6.14583552055993in"
height="2.0625in"}

Creación de archivo desde el servidor

![](./media/media/image54.png){width="4.180769903762029in"
height="0.38890857392825895in"}

Vista del archivo desde el cliente

![](./media/media/image55.png){width="6.14583552055993in"
height="0.6458333333333334in"}

Login desde el sistema operativo

![](./media/media/image56.png){width="6.14583552055993in"
height="5.14583552055993in"}![](./media/media/image57.png){width="6.14583552055993in"
height="5.14583552055993in"}

![](./media/media/image58.png){width="6.14583552055993in"
height="5.14583552055993in"}![](./media/media/image59.png){width="6.14583552055993in"
height="5.14583552055993in"}![](./media/media/image60.png){width="6.14583552055993in"
height="5.14583552055993in"}![](./media/media/image61.png){width="6.14583552055993in"
height="5.14583552055993in"}Configuración e instalación de samba en el
servidor

![](./media/media/image62.png){width="6.14583552055993in"
height="0.3645833333333333in"}![](./media/media/image63.png){width="6.145833333333333in"
height="2.1041655730533684in"}

![](./media/media/image64.png){width="6.145833333333333in"
height="1.7916655730533684in"}

![](./media/media/image65.png){width="6.14583552055993in"
height="1.7916666666666667in"}

![](./media/media/image66.png){width="6.14583552055993in"
height="0.25in"}

![](./media/media/image67.png){width="5.639179790026247in"
height="0.25001312335958004in"}

![](./media/media/image68.png){width="6.14583552055993in"
height="0.21875in"}

![](./media/media/image69.png){width="6.14583552055993in"
height="1.25in"}Contraseña: 12345678As

![](./media/media/image70.png){width="4.903029308836396in"
height="3.319615048118985in"}

Samba-tool para crear un usuario

![](./media/media/image71.png){width="6.14583552055993in"
height="0.90625in"}

![](./media/media/image72.png){width="4.180769903762029in"
height="1.0000513998250218in"}

![](./media/media/image73.png){width="4.875250437445319in"
height="0.25001312335958004in"}

Modificación del archivo smb.conf

![](./media/media/image74.png){width="4.80580271216098in"
height="4.514120734908136in"}

![](./media/media/image75.png){width="4.875250437445319in"
height="0.25001312335958004in"}

![](./media/media/image76.png){width="4.875250437445319in"
height="0.25001312335958004in"}

![](./media/media/image77.png){width="4.875250437445319in"
height="0.25001312335958004in"}

Configuración de samba en windows cliente

![](./media/media/image78.png){width="5.5in"
height="1.7916666666666667in"}

![](./media/media/image79.png){width="3.8125in"
height="4.916666666666667in"}

![](./media/media/image80.png){width="4.145833333333333in"
height="4.729166666666667in"}

Configuración avanzada del sistema

![](./media/media/image81.png){width="4.291666666666667in"
height="5.0625in"}

![](./media/media/image82.png){width="3.3645833333333335in"
height="4.072916666666667in"}

Ingresa el usuario y contraseña del administrador de samba en el
servidor:

-   Administrator

-   12345678As

Reinicia el sistema

![](./media/media/image83.png){width="2.1945570866141733in"
height="1.152836832895888in"}

![](./media/media/image84.png){width="2.555686789151356in"
height="1.3889599737532807in"}

![](./media/media/image85.png){width="4.15625in"
height="6.14583552055993in"}

Creación de un archivo en el servidor

![](./media/media/image86.png){width="5.2502701224846895in"
height="0.25001312335958004in"}

![](./media/media/image87.png){width="5.791965223097113in"
height="0.4305774278215223in"}

Vista del archivo desde windows

![](./media/media/image88.png){width="6.14583552055993in"
height="0.9479166666666666in"}

![](./media/media/image89.png){width="6.14583552055993in"
height="4.666666666666667in"}![](./media/media/image90.png){width="6.14583552055993in"
height="4.625in"}

![](./media/media/image91.png){width="6.14583552055993in"
height="4.645833333333333in"}

![](./media/media/image92.png){width="6.14583552055993in"
height="4.583333333333333in"}

![](./media/media/image93.png){width="6.14583552055993in"
height="1.0208333333333333in"}

Conclusion
==========
